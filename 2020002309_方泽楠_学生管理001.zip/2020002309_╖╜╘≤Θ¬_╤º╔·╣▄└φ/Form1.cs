﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2020002309_方泽楠_学生管理
{
    public partial class Form1 : Form
    {
        sxb s1 = new sxb(1);
        public Form1()
        {
            InitializeComponent();
            listBox1.Text = s1.ToString();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {

        }

        private void btnDown_Click(object sender, EventArgs e)
        {

        }

        private void btnC_Click(object sender, EventArgs e)
        {
            MessageBox.Show(s1.insert(int.Parse(textBox1.Text), int.Parse(textBox2.Text)) + "", "添加位置" + int.Parse(textBox1.Text), MessageBoxButtons.OKCancel);
        }

        private void btnD_Click(object sender, EventArgs e)
        {
            MessageBox.Show(s1.delIndex(int.Parse(textBox3.Text)) + "", "删除位置" + int.Parse(textBox3.Text), MessageBoxButtons.OKCancel);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            MessageBox.Show(s1.findI(int.Parse(textBox4.Text)) + "", "查询位置" + int.Parse(textBox4.Text), MessageBoxButtons.OKCancel);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
